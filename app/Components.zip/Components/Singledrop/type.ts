export interface DropdownOption {
    value?: string;
    label?: string;
}

export interface DropdownProps {
    options: DropdownOption[]
    label?: string
    onSelect: (selectedOptions: string[]) => void
    autofocus?: boolean
    disabled?: boolean
    name?: string
    required?: boolean
}

export interface Option {
    value?: string;
    label?: string;
}
