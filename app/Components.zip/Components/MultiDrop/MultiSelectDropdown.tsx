// import React, { useState } from 'react';
// import { MultiSelectDropdownProps } from './type';
// import './Dropdown.css';

// const MultiSelectDropdown: React.FC<MultiSelectDropdownProps> = ({
//   options,
//   onSelect,
// }) => {

//   const afterStyle: React.CSSProperties = {
//     content: "'\\27A4'",
//     position: 'absolute',
//     top: '0',
//     right: '10px',
//     transform: 'translateY(-50%)',
//     transformOrigin: 'center',
//     transition: 'transform 0.3s ease',
//   };


//   const [isActive, setIsActive] = useState(false);
//   const [selectedOptions, setSelectedOptions] = useState<string[]>([]);



//   const handleOptionToggle = (option: string) => {
//     if (selectedOptions.includes(option)) {
//       setSelectedOptions(selectedOptions.filter((item) => item !== option));
//     } else {
//       setSelectedOptions([...selectedOptions, option]);
//     }
//   };


//   if (isActive) {
//     afterStyle.transform = 'translateY(-50%) rotateZ(-90deg)';
//   }
//   // {options.map((option) => 
//   //   console.log(option.value)

//   // )}
//   return (
//     <div className='dropdown'>
//      <div
//         className={`dropdown-btn ${isActive ? 'dropdown-btn-before-active' : ''}`}
//         onClick={(e) => setIsActive(!isActive)}
//       >
//        {selectedOptions.length > 0 ? (
//   <div className="dropdown-selected">{selectedOptions.join(', ')}</div>
// ) : (
//   <div className="dropdown-placeholder">Select options</div>
// )}

// {isActive && (
//   <div className="dropdown-content">
//     {options.map((option: any) => (

//       <div
//       key={option.value}
//       onClick={() => handleOptionToggle(option.value)}
//       className={`dropdown-item ${
//         selectedOptions.includes(option.value) ? 'selected' : ''
//       }`}
//       >
//         {option.label}
//       </div>
//     ))}

//   </div>
// )}

//       </div>

//       <button onClick={() => onSelect(selectedOptions)}>Submit</button>
//     </div>
//   );
// };

// export default MultiSelectDropdown;

import React, { useState, ChangeEvent } from 'react';
import { MultiSelectDropdownProps } from './type';
import './Dropdown.css';
import Button from '../Button';

const MultiSelectDropdown: React.FC<MultiSelectDropdownProps> = ({
  options,
  onSelect,
}) => {
  const [isActive, setIsActive] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
  const [searchText, setSearchText] = useState('');

  const handleOptionToggle = (option: string) => {
    if (selectedOptions.includes(option)) {
      setSelectedOptions(selectedOptions.filter((item) => item !== option));
    } else {
      setSelectedOptions([...selectedOptions, option]);
      setSearchText('')
    }
  };

  const handleSearchInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearchText(e.target.value);
  };

  const filteredOptions: any[] = options.filter((option: any) =>
    option.label.toLowerCase().includes(searchText.toLowerCase())
  );
  const handleButtonClick = () => {
    setSelectedOptions([]);
    onSelect(selectedOptions);
  };
  return (
    <div className='dropdown'>
      <div
        className={`dropdown-btn ${isActive ? 'dropdown-btn-before-active' : ''}`}
        onClick={() => setIsActive(!isActive)}
      >
        {selectedOptions.length > 0 ? (
          <div className="dropdown-selected">{selectedOptions.join(', ')}</div>
        ) : (
          <div className="dropdown-placeholder">Select options</div>
        )}
        <div>


          {isActive && (
            <div
              className="dropdown-content"
              onClick={(e) => e.stopPropagation()} // Prevent closing on click inside the dropdown content

            >
              <input
                className='dropdown-search'
                type="text"
                placeholder="Search..."
                value={searchText}
                onChange={handleSearchInputChange}
              />
              {filteredOptions.map((option: any) => (
                <div
                  key={option.value}
                  className={`dropdown-item ${selectedOptions.includes(option.value) ? 'selected' : ''}`}
                  onClick={() => handleOptionToggle(option.value)}
                >
                  {option.label}
                </div>
              ))}
            </div>
          )}
        </div>

        <Button variant='primary_outline' onClick={handleButtonClick}>Submit</Button>
      </div>

    </div>
  );
};

export default MultiSelectDropdown;
