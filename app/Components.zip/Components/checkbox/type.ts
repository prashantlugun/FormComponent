export interface CheckboxProps {
    id?: string;
    name?: string;
    value?: string;
    label?: string;
    checked?: boolean;
    disabled?: boolean;
    multiple?: boolean;
    required?: boolean;
    onClick?: () => any;
    sx?: object;
};
