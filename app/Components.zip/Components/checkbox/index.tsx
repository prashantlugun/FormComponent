import React from 'react';
import { CheckboxProps } from './type';

export class Checkbox extends React.Component<CheckboxProps> {
    onClick: any;

    render() {
        const { id, name, value, label, checked, disabled, required, onClick, sx } = this.props;

        return (
            <div>
                <label>
                    <input
                        type="checkbox"
                        id={id}
                        name={name}
                        value={value}
                        checked={checked}
                        disabled={disabled ? true : false}
                        onClick={e => console.log(value)}
                        style={sx}
                    />
                    {label}
                </label>
            </div>
        );
    }
}

