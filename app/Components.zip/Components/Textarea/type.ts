export interface TextareaProps {
    id?: string;
    name?: string;
    value?: string;
    label?: string;
    rows?: number;
    cols?: number;
    autoFocus?: boolean;
    disabled?: boolean;
    maxLength?: number;
    placeholder?: string;
    required?: boolean;
    readOnly?: boolean;
};