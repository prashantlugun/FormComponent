import React from 'react';
import { TextareaProps } from './type';

const Textarea = (props: TextareaProps) => {

    const {
        id,
        name,
        value,
        label,
        rows,
        cols,
        autoFocus,
        disabled,
        maxLength,
        placeholder,
        required,
        readOnly
    } = props;

    return (
        <div>
            <label>
                {label}
                <textarea
                    id={id}
                    name={name}
                    value={value}
                    rows={rows}
                    cols={cols}
                    autoFocus={autoFocus ? true : false}
                    disabled={disabled ? true : false}
                    maxLength={maxLength}
                    placeholder={placeholder}
                    required={required ? true : false}
                    readOnly={readOnly ? true : false}
                >
                </textarea>
            </label>
        </div>
    );
}

export default Textarea;

