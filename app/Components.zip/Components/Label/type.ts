export interface LabelProps {
    id?: string;
    htmlfor?: string;
    variant?: string | undefined;
    size?: string | undefined;
    sx?: object
    children?: React.ReactNode;
}