import Button from './Components/Button';
import Input from './Components/Input';
import Label from './Components/Label';
import Radio from './Components/Radio';
import Textarea from './Components/Textarea';

const Home = () => {
  return (
    <>
      <Label
        sx={{
          color: 'green',
          textTransform: 'uppercase',
        }}
      >Label</Label>
      <Input
        placeholder='Blank Input'
      />
      <Input
        errorText='Text Field Custom Error'
        label='Custom Error'
        placeholder='Custom Error'
      />
      <Input
        label='Name'
        placeholder='Name'
      />
      <Input
        type='email'
        label='Email'
        placeholder='Email'
        errorText='Invalid email Front'
      />
      <Input
        type='password'
        label='Password'
        placeholder='Password'
        passwordVisibility
      />
      <Input
        disabled
        label='Disabled'
        placeholder='Disabled'
      />
      <Input
        label='ReadOnly'
        placeholder='ReadOnly'
        value='ReadOnly'
        readOnly
      />
      <h1>Button</h1>
      <Button>Submit</Button>
      <Button disabled >Disabled</Button>
      <Button variant='danger_outline' >Outline</Button>

      <Label>Text Area</Label>
      <Textarea
        placeholder="Text Area"
        rows={5}
      />
      <Radio
        label='Male'
        name='gender'
        />
      <Radio
        label='Female'
        name='gender'
      />
    </>
  );
};

export default Home;
