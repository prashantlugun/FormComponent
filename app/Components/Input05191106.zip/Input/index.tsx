"use client"

import React, { useState } from 'react';

// Types
import { inputProps } from './type';

// Style
import style from './input.module.css';

const _Alpha = (value: any) => { return new RegExp(/^[a-zA-Z\s]$/).test(value) };
const _Email = (value: any) => { return new RegExp(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/).test(value) };
const _Number = (value: any) => { return new RegExp(/^[0-9]*$/).test(value) };
const _StrongPassword = (value: any) => { return new RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/).test(value) };
const _IndMobileNumber = (value: any) => { return new RegExp(/^[7-9][0-9]{9}$/).test(value) };
const _IndPhoneNumber = (value: any) => { return new RegExp(/^\d{5}([- ]*)\d{6}$/).test(value) };
const _ForeignerMobileNumber = (value: any) => { return new RegExp(/^[0-9]{0,14}$/).test(value) };
const _ForeignerPhoneNumber = (value: any) => { return new RegExp(/^\+(?:[0-9] ?){6,14}[0-9]$/).test(value) };

const Input = ({
    type = 'text',
    label,
    title,
    id,
    name,
    value,
    placeholder,
    size,
    min,
    max,
    maxLength,
    step,
    alt,
    height,
    width,
    list,
    errorText,
    error,
    autoComplete,
    autoFocus,
    readOnly,
    disabled,
    multiple,
    required,
    passwordVisibility,
    noValidate,
    onChange,
    onFocus,
    onValidate,
    sx,
}: inputProps) => {

    const [visibility, setVisibility] = useState<boolean>(false)
    const [showErrorInfo, setShowErrorInfo] = useState<boolean>(false)
    const [isValid, setIsValid] = useState<boolean>(true);
    const [erorrText, setErrorText] = useState<string>("");

    const defaultErrorText = 'This field contains error!';

    const validate = (e: any) => {
        console.log(e.target.value);
        if (type === "text") {
            if (e.target.value === "") {
                setIsValid(false);
                onValidate(false);
                setErrorText(errorText ? errorText : "text field can't be empty")
            } else {
                setIsValid(true);
                onValidate(true);

            }
        }
        if (type === "password") {
            const passRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/
            const evaluateRegex = passRegex.test(e.target.value);
            if (evaluateRegex) {
                setIsValid(true);
                onValidate(true);
                setErrorText("");
            }
            else {
                setIsValid(false);
                onValidate(false);
                setErrorText(errorText? errorText: "Password must contain a Uppercase,lowercase,special,number and must be between 8-16 characters ")
            }
        }
        if (type === "email") {
            const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/
            const evaluateRegex = emailRegex.test(e.target.value);
            if (evaluateRegex) {
                setIsValid(true);
                onValidate(true);
                setErrorText("");
            }
            else {
                setIsValid(false);
                onValidate(false);
                setErrorText(errorText? errorText: "Invalid email")
            }
        }
        if (type === "url") {
            const urlRegex = new RegExp(/^(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+\.){1,}[a-zA-Z]{2,}(\S*)?$/)
            const evaluateRegex = urlRegex.test(e.target.value);
            if (evaluateRegex) {
                setIsValid(true);
                onValidate(true);
                setErrorText("");
            }
            else {
                setIsValid(false);
                onValidate(false);
                setErrorText("Invalid url")
            }
        }
    };

    console.log('erorrText : ', erorrText)

    return (
        <>
            <div className={style.textField}>
                { <label
                    style={
                        erorrText ? {
                            color: 'red'
                        } : {}
                    }
                >{label}</label>
                }
                <div className={style.input}>
                    <input
                        className={style['mobile-Number']}
                        title={title}
                        type={!type || type === '' || visibility ? 'text' : type}
                        id={id}
                        name={name}
                        value={value}
                        placeholder={placeholder}
                        size={size}
                        min={min}
                        max={max}
                        maxLength={maxLength}
                        step={step}
                        alt={alt}
                        height={height}
                        width={width}
                        list={list}
                        autoComplete={autoComplete}
                        autoFocus={autoFocus ? true : false}
                        disabled={disabled}
                        readOnly={readOnly ? true : false}
                        multiple={multiple ? true : false}
                        required={required ? true : false}
                        onChange={onChange}
                        onFocus={onFocus}
                        validate={validate}
                        onBlur={noValidate ? onblur : validate}
                        style={{ 
                            ...sx,
                            borderColor: isValid ? "" : "red" ,
                        }}
                    />

                    {type === 'password' && passwordVisibility && (
                        <img
                            className={style.password}
                            // className={classes.icons}
                            style={error ? { marginLeft: '-60px' } : {}}
                            src={
                                visibility
                                    ? 'https://img.icons8.com/ios-glyphs/30/visible--v1.png'
                                    : 'https://img.icons8.com/ios-glyphs/30/closed-eye--v1.png'
                            }
                            alt={visibility ? 'hide' : 'show'}
                            onClick={() => setVisibility(!visibility)}
                        />
                    )}
                    {erorrText && (
                        <img
                            // error-data={errorText ? errorText : defaultErrorText}
                            className={style.infoImg}
                            // title={errorText ? errorText : defaultErrorText}
                            // className={classes.icons}
                            src='https://img.icons8.com/fluency/48/info.png'
                            alt='info'
                            onMouseEnter={() => {
                                setShowErrorInfo(!showErrorInfo)
                            }}
                            onMouseLeave={() => {
                                setShowErrorInfo(!showErrorInfo)
                            }}
                        />
                    )}
                    {error && showErrorInfo && (
                        <div className={style.errorInfo}>
                            {erorrText ? erorrText : defaultErrorText}
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

export default Input;


const openEye = () => {
    return (
        <>
            <img width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/visible--v1.png" alt="visible--v1" />
        </>
    )
}
