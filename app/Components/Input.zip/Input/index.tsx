"use client"

import React, { useState } from 'react';

// Types
import { inputProps } from './type';

// Style
import style from './input.module.css';

const Input = ({
    type = 'text',
    label,
    title,
    id,
    name,
    value,
    placeholder,
    size,
    min,
    max,
    maxLength,
    step,
    alt,
    height,
    width,
    list,
    errorText,
    error,
    autoComplete,
    passwordVisibility,
    autoFocus,
    readOnly,
    disabled,
    multiple,
    required,
    onChange,
    onFocus,
    sx,
}: inputProps) => {

    const [visibility, setVisibility] = useState<boolean>(false)
    const [showErrorInfo, setShowErrorInfo] = useState<boolean>(false)

    const defaultErrorText = 'This field contains error!'

    return (
        <>
            <div className={style.textField}>
                {<label
                    style={
                        error ? {
                            color: 'red'
                        } : {}
                    }
                >{label}</label>
                }
                <div className={style.input}>
                    <input
                        className={style['mobile-Number']}
                        title={title}
                        type={!type || type === '' || visibility ? 'text' : type}
                        id={id}
                        name={name}
                        value={value}
                        placeholder={placeholder}
                        size={size}
                        min={min}
                        max={max}
                        maxLength={maxLength}
                        step={step}
                        alt={alt}
                        height={height}
                        width={width}
                        list={list}
                        autoComplete={autoComplete}
                        autoFocus={autoFocus ? true : false}
                        disabled={disabled}
                        readOnly={readOnly ? true : false}
                        multiple={multiple ? true : false}
                        required={required ? true : false}
                        onChange={onChange}
                        onFocus={onFocus}
                        onBlur={(e) => { return e.currentTarget.blur(); }}
                        style={
                            sx
                        }
                    />

                    {type === 'password' && passwordVisibility && (
                        <img
                            className={style.password}
                            // className={classes.icons}
                            style={error ? { marginLeft: '-60px' } : {}}
                            src={
                                visibility ? 'https://img.icons8.com/ios-glyphs/30/visible--v1.png' : 'https://img.icons8.com/ios-glyphs/30/closed-eye--v1.png'
                            }
                            alt={visibility ? 'hide' : 'show'}
                            onClick={() => setVisibility(!visibility)}
                        />
                    )}
                </div>
                {error && (
                    <div
                        className={style.infoError}
                    >
                        <img
                            // error-data={errorText ? errorText : defaultErrorText}
                            className={style.infoImg}
                            title={errorText ? errorText : defaultErrorText}
                            // className={classes.icons}
                            src='https://img.icons8.com/fluency/48/info.png'
                            alt='info'
                            onClick={() => {
                                setShowErrorInfo(!showErrorInfo)
                            }}
                        />
                    </div>
                )}
            </div>
            {error && showErrorInfo && (
                <div className='inputsModule__errorInfo'>
                    {errorText ? errorText : defaultErrorText}
                </div>
            )}
        </>
    );
};

export default Input;


const openEye = () => {
    return (
        <>
            <img width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/visible--v1.png" alt="visible--v1" />
        </>
    )
}
